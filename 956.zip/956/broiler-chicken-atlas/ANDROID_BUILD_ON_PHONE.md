# Build and install the Android APK from your phone

This project is Android-ready using Capacitor. The included GitHub Actions workflow builds the APK in the cloud, so you do not need Android Studio on your phone.

## Phone-only method
1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository, for example `broiler-chicken-atlas`.
3. Upload all files/folders from this project to the repository (not the ZIP itself if you want Actions to run automatically).
4. Open the repository's **Actions** tab.
5. Select **Build Broiler Chicken Atlas APK**.
6. Tap **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run and scroll to **Artifacts**.
9. Download `Broiler-Chicken-Atlas-APK`.
10. Extract the downloaded artifact if GitHub gives you a ZIP; inside is `app-debug.apk`.
11. Tap the APK and install it. Android may ask you to allow Chrome/Files to install unknown apps.

The APK is a debug build intended for personal installation/testing. A Play Store release needs a signed release build and app-signing setup.
