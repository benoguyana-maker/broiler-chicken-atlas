# Broiler Chicken Atlas

A production-quality React + Vite educational atlas for poultry production, processing, anatomy, QC and food safety.

## Run locally

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local Vite URL shown in the terminal.

## Build

`npm run build`

## Notes
- No Three.js, WebGL or 3D anatomy.
- Local progress and pre-op checklist state use localStorage.
- The app is data-driven and uses reusable components.
- Regulatory numeric limits are intentionally not invented; verify jurisdiction-specific requirements and plant SOPs.
- External image/source URLs should be reviewed for licensing and availability before commercial deployment.
